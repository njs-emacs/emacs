#include	"lisp.h"

lo Fcaar(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcdar(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcadr(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcddr(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcaaar(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcdaar(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcadar(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcddar(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcaadr(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcdadr(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcaddr(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcdddr(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcaaaar(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcdaaar(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcadaar(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcddaar(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcaadar(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcdadar(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcaddar(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcdddar(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcaaadr(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcdaadr(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcadadr(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcddadr(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcaaddr(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcdaddr(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcadddr(o)
{
    if (NIL(o = FFFcar(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

lo Fcddddr(o)
{
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    if (NIL(o = FFFcdr(o))) return(o) ;
    return(o) ;) ;
    }

